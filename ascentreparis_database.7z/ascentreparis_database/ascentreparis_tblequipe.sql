CREATE DATABASE  IF NOT EXISTS `ascentreparis` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ascentreparis`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ascentreparis
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblequipe`
--

DROP TABLE IF EXISTS `tblequipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblequipe` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Libelle` varchar(255) NOT NULL DEFAULT '',
  `Commentaire` varchar(8000) DEFAULT NULL,
  `InformationEntrainements` varchar(800) DEFAULT NULL,
  `InformationResponsable` varchar(500) DEFAULT NULL,
  `InformationDivision` varchar(500) DEFAULT NULL,
  `LienClassement` varchar(500) DEFAULT NULL,
  `Ordre` int(11) NOT NULL,
  `CheminPhoto` varchar(250) DEFAULT NULL,
  `CheminCalendrier` varchar(250) DEFAULT NULL,
  `CheminFicheEntrainement` varchar(250) DEFAULT NULL,
  `DateCreation` datetime DEFAULT NULL,
  `isActif` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblequipe`
--

LOCK TABLES `tblequipe` WRITE;
/*!40000 ALTER TABLE `tblequipe` DISABLE KEYS */;
INSERT INTO `tblequipe` VALUES (1,'Senior2','Commentaire senior. modif','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','Nordine (06 25 54 10 56)','5ème division de district (92) poule B h22222','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',1,'~/Ressources/Fichiers/Uploads/Equipe/Photo_1.JPG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_1.DOCX','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_1.PDF','0001-01-01 00:00:00',1),(2,'U17','35\r\n1\r\n12\r\n1\r\n1\r\n1','2\r\n2\r\n2\r\n2\r\n2\r\n2\r\n2','3\r\n3\r\n3\r\n3\r\n3\r\n3','4\r\n4\r\n4\r\n4\r\n4\r\n4\r\n','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',2,'~/Ressources/Fichiers/Uploads/Equipe/Photo_2.JPG',NULL,'~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_2.V2DOCX','0001-01-01 00:00:00',1),(3,'U15','Commentaire U152','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','Gagni (06 52 35 64 14) et Balthazar (07 62 77 15 15)','5ème division de district (92) poule B','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',3,'~/Ressources/Fichiers/Uploads/Equipe/Photo_3.JPG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_3.PDF','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_3.PDF','0001-01-01 00:00:00',1),(4,'U13','Commentaire U13','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','NOM PRENOM','5ème division de district (92) poule B','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',4,NULL,NULL,'~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_4.PDF','0001-01-01 00:00:00',1),(5,'U11','Commentaire U11','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','NOM PRENOM222','5ème division de district (92) poule B','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',5,NULL,NULL,NULL,'0001-01-01 00:00:00',1),(6,'U9','Commentaire U9','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','NOM PRENOM','5ème division de district (92) poule B','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',6,'~/Ressources/Fichiers/Uploads/Equipe/Equipe_1.JPEG',NULL,NULL,'2017-02-23 11:56:23',1),(7,'U7','Commentaire U7','Mercredi au Stade Dauvin (Porte de Clignancourt) de 20h à 22h et le Vendredi au Stade des fillettes (Porte de la Chapelle) de 19h à 20h30.','NOM PRENOM','5ème division de district (92) poule B','https://www.fff.fr/championnats/fff/district-des-hauts-de-seine/2016/331645-seniors-cinquieme-division/phase-1/poule-2/derniers-resultats',7,NULL,'~/Ressources/Fichiers/Uploads/Equipe/Calendrier_7.PDF',NULL,'0001-01-01 00:00:00',1),(8,'Futsal','A partir de 18 ans','Jeudi 20h45-22h15 et Samedi 18-20h. Gymnase Jean Dame','Basile (06 64 16 44 98)','Loisir22','',8,NULL,NULL,NULL,'0001-01-01 00:00:00',1),(9,'testEquipe','','','','','',0,NULL,NULL,NULL,'0001-01-01 00:00:00',0),(10,'n\'importe quoi','ere\'ere','\'ere\'','ereer\'\'erer\'','eree\'ere','\'ere',99,NULL,NULL,NULL,'2017-03-08 18:55:58',0),(16,'test 2','','','','','',9999,NULL,NULL,NULL,'2017-03-08 19:07:41',0),(18,'testEquipe2','','','','','',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_18.JPG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_18.PDF',NULL,'2017-03-08 20:47:24',0),(19,'testEquipe HEHE','1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n','1\r\n2\r\n3','1\r\n2\r\n3','1\r\n2','2',9999,NULL,'~/Ressources/Fichiers/Uploads/Equipe/Calendrier_19.DOCX','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_19.PDF','0001-01-01 00:00:00',0),(20,'test','','','','','',9999,NULL,NULL,NULL,'2017-03-11 18:09:54',0),(22,'testEquipe23','','','','','',9999,NULL,NULL,NULL,'2017-03-11 18:27:14',0),(24,'testEquipe','','','','','',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_24.JPG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_24.PDF','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_24.V2DOCX','2017-03-11 18:34:45',0),(25,'rrrr','','','','','',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_25.JPG',NULL,NULL,'2017-03-11 18:42:06',0),(26,'TEST44','','','','','',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_26.JPG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_26.V2DOCX','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_26.PDF','2017-03-11 18:46:24',0),(27,'on va voir...','','','','','',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_27.JPG',NULL,'~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_27.JPG','2017-03-11 18:48:06',0),(28,'1','','','','','',9999,NULL,NULL,NULL,'2017-03-11 18:54:30',0),(29,'2','','','','','',9999,NULL,NULL,NULL,'2017-03-11 18:56:31',0),(30,'3','','','','','',9999,NULL,NULL,NULL,'2017-03-11 19:00:41',0),(31,'4','','','','','',9999,NULL,NULL,NULL,'2017-03-11 19:02:11',0),(32,'4','','','','','',9999,NULL,NULL,NULL,'2017-03-11 19:03:41',0),(33,'5','','','','','',9999,NULL,NULL,NULL,'2017-03-11 19:03:46',0),(34,'sautLignes','1\r\n2\r\n3','1\r\n2\r\n3','1\r\n2\r\n3','1\r\n2\r\n3','',9999,NULL,NULL,NULL,'2017-03-11 19:07:29',0),(35,'1','','','','','',9999,NULL,NULL,NULL,'0001-01-01 00:00:00',0),(36,'2','','','','','',9999,NULL,NULL,NULL,'2017-03-11 19:08:35',0),(37,'TestCréation','','','','','',9999,NULL,'~/Ressources/Fichiers/Uploads/Equipe/Calendrier_37.PDF',NULL,'2017-03-12 10:39:53',0),(38,'Libellé2','com haha','entr','resp','div','lien',9999,'~/Ressources/Fichiers/Uploads/Equipe/Photo_38.PNG','~/Ressources/Fichiers/Uploads/Equipe/Calendrier_38.PNG','~/Ressources/Fichiers/Uploads/Equipe/FicheEntrainement_38.PNG','0001-01-01 00:00:00',1),(39,'testcrea','','','','','',9999,NULL,NULL,NULL,'2017-04-25 19:16:04',0),(40,'ttt','','','','','',9999,NULL,NULL,NULL,'2017-04-26 18:37:09',1),(41,'44','','','','','',9999,NULL,NULL,NULL,'2017-04-26 18:44:52',1);
/*!40000 ALTER TABLE `tblequipe` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-15 11:25:09
