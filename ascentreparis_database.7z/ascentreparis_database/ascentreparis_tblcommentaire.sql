CREATE DATABASE  IF NOT EXISTS `ascentreparis` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ascentreparis`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ascentreparis
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcommentaire`
--

DROP TABLE IF EXISTS `tblcommentaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcommentaire` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `NomUtilisateur` varchar(50) NOT NULL DEFAULT '',
  `Message` varchar(800) NOT NULL DEFAULT '',
  `idActualite` int(11) unsigned DEFAULT NULL,
  `idDocument` int(11) unsigned DEFAULT NULL,
  `DateCreation` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idActualite` (`idActualite`),
  KEY `idDocument` (`idDocument`),
  CONSTRAINT `tblcommentaire_ibfk_1` FOREIGN KEY (`idActualite`) REFERENCES `tblactualite` (`id`),
  CONSTRAINT `tblcommentaire_ibfk_2` FOREIGN KEY (`idDocument`) REFERENCES `tbldocument` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcommentaire`
--

LOCK TABLES `tblcommentaire` WRITE;
/*!40000 ALTER TABLE `tblcommentaire` DISABLE KEYS */;
INSERT INTO `tblcommentaire` VALUES (57,'r','r',6,NULL,'2017-04-17 10:12:07'),(58,'nul','nullll',10,NULL,'2017-04-17 10:31:42'),(60,'reerer','rr',10,NULL,'2017-04-17 10:42:21'),(61,'rtrt','tt',14,NULL,'2017-04-17 22:50:37'),(62,'rtrt','rr',14,NULL,'2017-04-17 22:50:44'),(64,'t','rtr',8,NULL,'2017-04-18 19:53:47'),(65,'f','d',15,NULL,'2017-04-20 19:30:21'),(66,'11','1\n2\n3',8,NULL,'2017-04-24 18:48:46'),(67,'user','1\n2\n3\n\n4',15,NULL,'2017-04-24 19:06:53'),(68,'r','rr',15,NULL,'2017-04-24 19:39:28'),(69,'f','f',15,NULL,'2017-04-24 19:39:54'),(70,'f','jj',15,NULL,'2017-04-24 19:40:18'),(71,'f','h',15,NULL,'2017-04-24 19:41:04'),(72,'ù','ù',15,NULL,'2017-04-24 19:44:30'),(73,'e','e',10,NULL,'2017-05-03 13:05:59'),(74,'ee','e',10,NULL,'2017-05-03 13:06:01'),(75,'eee','e',10,NULL,'2017-05-03 13:06:03'),(76,'eeee','e',10,NULL,'2017-05-03 13:06:06'),(77,'eeee','e',10,NULL,'2017-05-03 13:06:08'),(78,'eeee','tets , : http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5',10,NULL,'2017-05-03 13:07:05'),(79,'zez','http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5',32,NULL,'2017-05-03 13:36:03');
/*!40000 ALTER TABLE `tblcommentaire` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-15 11:25:09
