CREATE DATABASE  IF NOT EXISTS `ascentreparis` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ascentreparis`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ascentreparis
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblactualite`
--

DROP TABLE IF EXISTS `tblactualite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblactualite` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `CheminDocument` varchar(255) DEFAULT '',
  `Titre` varchar(50) NOT NULL DEFAULT '',
  `Texte` varchar(8000) DEFAULT '',
  `DateCreation` datetime DEFAULT NULL,
  `Resume` varchar(400) NOT NULL DEFAULT '',
  `idEquipe` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idEquipe` (`idEquipe`),
  CONSTRAINT `tblactualite_ibfk_1` FOREIGN KEY (`idEquipe`) REFERENCES `tblequipe` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblactualite`
--

LOCK TABLES `tblactualite` WRITE;
/*!40000 ALTER TABLE `tblactualite` DISABLE KEYS */;
INSERT INTO `tblactualite` VALUES (1,'','Titre1','test texte','2017-02-16 00:18:17','123456789\r\n123456789 zeze ttt  ththt hthththt hththththtntvh jtbtbbtjbtbt ht bhthgbtbthgg htyy yyyyyyy 456789 zeze ttt  ththt hthththt htzen\r\neeeee erre rrr trtrtrtrtrtrtttrt rtr',1),(5,'','Sauts à la ligne','','2017-02-16 00:54:09','123456789\n123456789 zeze ttt  ththt hthththt hththththtntvh jtbtbbtjbtbt ht bhthgbtbthgg htyy yyyyyyy 456789 zeze ttt  ththt hthththt htzen\neeeee erre rrr trtrtrtrtrtrtttrt rtr',NULL),(6,'','Victoire des séniors','','2017-02-23 11:48:05','123456789\n123456789 zeze ttt  ththt hthththt hththththtntvh jtbtbbtjbtbt ht bhthgbtbthgg htyy yyyyyyy 456789 zeze ttt  ththt hthththt htzen\neeeee erre rrr trtrtrtrtrtrtttrt rtr',1),(8,'~/Ressources/Fichiers/Uploads/Actualite/Actualite_8.JPG','Victoire des U17','Compos:\r\ngb\r\ndg\r\ndd\r\ndc\r\nmc\r\nmc\r\nmg\r\nmd\r\nmoc\r\nbu\r\n\r\nbrazezz\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nCompos:\r\ngb\r\ndg\r\ndd\r\ndc\r\nmc\r\nmc\r\nmg\r\nmd\r\nmoc\r\nbu\r\n\r\nbrazezz\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nCompos:\r\ngb\r\ndg\r\ndd\r\ndc\r\nmc\r\nmc\r\nmg\r\nmd\r\nmoc\r\nbu\r\n\r\nbrazezz\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr\r\n\r\n\r\nzezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr zezeezee rrrr rrr rrrfrtrt rrttrtr\r\n','2017-02-23 11:57:07','123456789\n123456789 zeze ttt  ththt hthththt hththththtntvh jtbtbbtjbtbt ht bhthgbtbthgg htyy yyyyyyy 456789 zeze ttt  ththt hthththt htzen\neeeee erre rrr trtrtrtrtrtrtttrt rtr',2),(10,'~/Ressources/Fichiers/Uploads/Actualite/Document_10.JPG','LES NOTES DE MARSEILLE','Pelé (6) : Un clean-sheet de plus pour l\'Albatros, qui n\'a quasiment pas eu à déployer ses ailes.\r\n\r\nSakai (6) : Moins remuant que d\'habitude sur le plan offensif, il n\'a cependant jamais été autant inquiété dans son couloir. Et surtout, il a eu le droit pour la première fois à deux vibrants hommages. Une banderole du virage sud, «?Sakai, notre samouraï?» , et une interview embarrassante de Paga. «?You areuh fatigué, Sakai ? Arigato?» Bienvenue en France, Hiroki, enfin. Remplacé par Fanni, qui a dû laisser la stéréo sans surveillance au vestiaire pendant dix minutes. \r\n\r\nSertic (5,5) : Il n\'a tellement rien eu à faire ce soir qu\'il a probablement eu le temps de devenir le premier homme du monde à terminer Candy Crush. A au moins le mérite d\'être plus rassurant que tous les défenseurs centraux de l\'OM.\r\n\r\nRolando (5) : Le papy un peu gênant qui ferait sûrement mieux d\'arrêter avant de se faire un tour de rein, mais qu\'on aime quand même énormément parce sa passion pour le football en est presque émouvante. Thierry Rolando.\r\n\r\nÉvra (5) : Absolument rien de neuf sous le soleil. Tonton Pat\' a livré une prestation à l\'image de ses capacités actuelles. Serein lorsqu\'il peut la jouer à l\'expérience, dépassé dès qu\'il se retrouve en un contre un avec un peu trop d\'espace. Vrais reconnaissent Évra(is).\r\n\r\nLopez (6) : En difficulté ces dernières semaines, il a repris du poil de la bête ce soir en misant sur ses points forts : une qualité de passe proche de la perfection et une grande disponibilité à la construction.\r\n\r\nLes notes de Saint-Étienne\r\n\r\nVainqueur (6) : Entre la défense parfois fébrile et pataude, et l\'attaque de feu parfois trop enthousiaste, il est le garant de l\'équilibre de cette équipe. Pas forcément très sexy, mais ô combien précieux comme rôle.\r\n\r\nSanson (8) : Dix et onzième passes décisives de la saison. Record personnel. Selon la Bible, il tire sa force exceptionnelle de la longueur de ses cheveux. Mouais. Vu ce qu\'on a vu ce soir, ça tient surtout à la douceur de ses contrôles orientés. \r\n\r\nPayet (7) : Des passes soyeuses, des déplacements intelligents et un but en guise de cerise sur le gâteau. Il a cette qualité de bien faire jouer ses coéquipiers. Un chef d\'orchestre qui fait du sport.\r\n\r\nGomis (6,5) : Dix-septième but de la saison. Record personnel. Peu de ballons à se mettre sous la dent, mais toujours aussi rapide pour dégainer fort quand il le faut. Un véritable sniper. Baffie Gomis. Remplacé par Sarr dans les arrêts de jeu. Pour la forme.\r\n\r\nThauvin (8,5) : Onze et douzième buts de la saison. Record personnel. Fier comme un coq lorsqu\'il réussit ses prouesses techniques, il a encore enivré le Vélodrome, comme à chaque fois qu\'il est dans un grand soir. Florian Coq-au-vin. Remplacé par Njie en fin de match, venu faire ses deux ou trois sprints hebdomadaires.\r\n\r\n\r\nPAR KEVIN CHARNAY\r\n','2017-04-17 10:17:17','Grâce à un quatuor Sanson-Payet-Thauvin-Gomis dans une forme olympique, l\'OM a roulé sur Saint-Étienne. Une idée du potentiel marseillais lorsqu\'il est bien exploité.\r\nPAR KEVIN CHARNAY DIMANCHE 16 AVRIL',3),(12,'~/Ressources/Fichiers/Uploads/Actualite/Document_12.MOV','test actu video MOV','rr\r\np','2017-04-17 12:42:59','uu',3),(14,'~/Ressources/Fichiers/Uploads/Actualite/Document_14.M4V','test actu video M4V','rroo\r\nyy','2017-04-17 12:55:58','haha',NULL),(15,'~/Ressources/Fichiers/Uploads/Actualite/Document_15.JPG','1','dfddd fdfd22','2017-04-17 22:57:14','1',NULL),(31,'~/Ressources/Fichiers/Uploads/Actualite/Document_31.PNG','ff','','2017-04-25 19:29:30','f',NULL),(32,'~/Ressources/Fichiers/Uploads/Actualite/Document_32.PNG','ttest crea','e','2017-04-26 09:44:16','tets , : http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5http://ascentredeparis.fr/Document/AfficherDocuments?idCategorieDocument=5',3),(33,NULL,'dd','jgg\r\nhttp://Google.fr','2017-04-26 18:37:19','HAHA :\r\nhttp://Google.fr',NULL);
/*!40000 ALTER TABLE `tblactualite` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-15 11:25:09
