CREATE DATABASE  IF NOT EXISTS `ascentreparis` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ascentreparis`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ascentreparis
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbldocument`
--

DROP TABLE IF EXISTS `tbldocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbldocument` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `CheminDocument` varchar(250) DEFAULT '',
  `idCategorieDocument` int(11) unsigned DEFAULT NULL,
  `Ordre` int(11) NOT NULL DEFAULT '999999',
  `Titre` varchar(50) NOT NULL DEFAULT '',
  `Texte` varchar(250) NOT NULL DEFAULT '',
  `DateCreation` datetime NOT NULL,
  `NomFichierUpload` varchar(150) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `CheminDocument` (`CheminDocument`),
  KEY `idCategorieDocument` (`idCategorieDocument`),
  CONSTRAINT `tbldocument_ibfk_1` FOREIGN KEY (`idCategorieDocument`) REFERENCES `tblcategoriedocument` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldocument`
--

LOCK TABLES `tbldocument` WRITE;
/*!40000 ALTER TABLE `tbldocument` DISABLE KEYS */;
INSERT INTO `tbldocument` VALUES (23,'~/Ressources/Fichiers/Uploads/Document/Document_1.jpg',9,99999,'doc1','testdoc','2017-02-16 00:03:47','DOC.DOC'),(24,'~/Ressources/Fichiers/Uploads/Document/Document_24.jpg',9,99999,'doc 2','haha','2017-02-16 00:04:13','DOC.DOC'),(25,'~/Ressources/Fichiers/Uploads/Document/Document_25.jpg',9,99999,'Z','Z','2017-02-16 00:04:36','DOC.DOC'),(26,'~/Ressources/Fichiers/Uploads/Document/Document_26.PDF',5,99999,'Calendrier 2017','','2017-02-16 20:28:13','PDF.PDF'),(27,'~/Ressources/Fichiers/Uploads/Document/Document_27.PDF',5,99999,'Calendrier 2016','','2017-02-16 20:28:28','PDF.PDF'),(29,'~/Ressources/Fichiers/Uploads/Document/Document_29.PDF',5,99999,'Calendrier 2013','','2017-02-16 20:29:08','PDF.PDF'),(33,'~/Ressources/Fichiers/Uploads/Document/Document_33.jpg',9,99999,'Cadets A 1949-1950','Test\r\n\"\'\r\n\"\r\n\'\"\r\n\"\r\n\'\"rr','2017-02-16 20:30:56','DOC.DOC'),(34,'~/Ressources/Fichiers/Uploads/Document/Document_34.jpg',9,99999,'1955-1956 Senuir B','','2017-02-16 20:32:03','DOC.DOC'),(35,'~/Ressources/Fichiers/Uploads/Document/Document_35.jpg',9,99999,'','','2017-02-16 20:32:11','DOC.DOC'),(36,'~/Ressources/Fichiers/Uploads/Document/Document_36.jpg',9,99999,'','','2017-02-16 20:32:16','DOC.DOC'),(37,'~/Ressources/Fichiers/Uploads/Document/Document_37.jpg',9,99999,'','','2017-02-16 20:32:20','DOC.DOC'),(38,'~/Ressources/Fichiers/Uploads/Document/Document_38.jpg',9,99999,'','','2017-02-16 20:32:25','DOC.DOC'),(39,'~/Ressources/Fichiers/Uploads/Document/Document_39.jpg',9,99999,'','','2017-02-16 20:32:30','DOC.DOC'),(40,'~/Ressources/Fichiers/Uploads/Document/Document_40.jpg',9,99999,'','','2017-02-16 20:32:36','DOC.DOC'),(41,'~/Ressources/Fichiers/Uploads/Document/Document_41.jpg',9,99999,'','','2017-02-16 20:32:43','DOC.DOC'),(42,'~/Ressources/Fichiers/Uploads/Document/Document_42.jpg',9,99999,'','','2017-02-16 20:32:47','DOC.DOC'),(43,'~/Ressources/Fichiers/Uploads/Document/Document_43.jpg',9,99999,'','','2017-02-16 20:32:52','DOC.DOC'),(44,'~/Ressources/Fichiers/Uploads/Document/Document_44.jpg',8,99999,'','','2017-02-16 20:32:58','DOC.DOC'),(45,'~/Ressources/Fichiers/Uploads/Document/Document_45.jpg',8,99999,'','','2017-02-16 20:33:15','DOC.DOC'),(49,'~/Ressources/Fichiers/Uploads/Document/Document_49.JPG',4,99999,'Base pédagogique','','2017-02-16 20:34:14',''),(53,'~/Ressources/Fichiers/Uploads/Document/Document_53.jpg',8,99999,'Test document','Test etxt','2017-02-21 19:01:24','1999-2000 U17.jpg'),(59,'~/Ressources/Fichiers/Uploads/Document/Document_59.JPG',4,9999,'','','2017-03-19 11:34:42','Document_'),(60,'~/Ressources/Fichiers/Uploads/Document/Document_60.JPG',4,9999,'','','2017-03-19 11:37:10','Document_24.jpg'),(70,'~/Ressources/Fichiers/Uploads/Document/Document_70.PNG',4,9999,'DOC1','Quand les visages de Jacques Chirac et de Jean-Marie Le Pen se sont affichés à la télévision, à 20 heures, au soir du 21 avril 2002, la stupeur et l’effroi ont saisi les habitants de la cité des Cosmonautes, e\r\n','2017-04-27 18:11:19','C:UsersfrlaruDownloadsadministration.png'),(71,'~/Ressources/Fichiers/Uploads/Document/Document_71.PNG',4,9999,'DOC 2','Quand les visages de de Jean-Marie Le Pe ffffffffffffffffffffhttp://www.lemonde.fr/les-decodeurs/article/2017/04/26/pourquoi-les-legislatives-s-annoncent-incertaines-quel-que-soit-le-vainqueur-de-la-presidentielle_5117602_4355770.html#mvVwoBZSPyEVQr\r','2017-04-27 18:12:03','C:UsersfrlaruDownloadsadministration.png'),(72,'~/Ressources/Fichiers/Uploads/Document/Document_72.MOV',5,9999,'Test video','','2017-05-24 15:31:55','C:UsersfrlaruDocumentsDocument_62.MOV'),(73,'~/Ressources/Fichiers/Uploads/Document/Document_73.MP4',5,99999,'test2','','2017-05-24 15:32:33','C:UsersfrlaruDocumentsDocument_64.MP4'),(74,'~/Ressources/Fichiers/Uploads/Document/Document_74.MP4',10,9999,'test3','','2017-05-24 15:42:52','C:UsersfrlaruDownloadsVID_20170504_144719.mp4'),(75,'~/Ressources/Fichiers/Uploads/Document/Document_75.MP4',10,9999,'MP4','','2017-05-31 13:25:39','D:usersfrlaruDocumentsDocument_64.MP4'),(76,'~/Ressources/Fichiers/Uploads/Document/Document_76.AVI',10,9999,'AVI','','2017-05-31 13:41:47','D:usersfrlaruDownloads2014 mai champion.AVI'),(77,'~/Ressources/Fichiers/Uploads/Document/Document_77.JPG',5,9999,'TEST','','2017-06-01 12:45:20','D:usersfrlaruDownloadsphoto1.jpg'),(78,'~/Ressources/Fichiers/Uploads/Document/Document_78.JPG',5,9999,'TERST2','','2017-06-01 12:45:31','D:usersfrlaruDownloadsphoto_passport.JPG');
/*!40000 ALTER TABLE `tbldocument` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-15 11:25:09
